package universidadulp.main;

import universidadulp.AccesoADatos.InscripcionData;
import universidadulp.Entidades.Inscripcion;
import universidadulp.Vistas.Notas;



public class Main {

    public static void main(String[] args) {
     
        Notas nota=new Notas();
        
        nota.mostrarComboBox();
    }
}
